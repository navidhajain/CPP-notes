// Menu based ARRAY implementation of SORTED LIST

#include<iostream.H>
#include<conio.H>

const N=5;

class SORTED_ARRAY
{
	float ARRAY[N];
	int REAR;
 public:
	SORTED_ARRAY(){REAR=-1;}
	void ADD();
	void DELETE();
	void DISPLAY();
};


void SORTED_ARRAY::ADD()
{
	float Temp;
	int i,j;

	if(REAR==N-1) //Checks overflow
		cout<<"\n\nOverflow! Addition of new element is not possible\n";

	 else
		{
		REAR++;

		cout<<"\n\nEnter the new element:";
		cin>>Temp;

		for(i=0;i<REAR && ARRAY[i]<Temp;i++); 	//Find the location for the new element

		for(j=REAR;j>=i;j--)
			ARRAY[j]=ARRAY[j-1];						//Shifting of elements downward

		ARRAY[i]=Temp;                         //Copy the element
		}
}


void SORTED_ARRAY::DELETE()
{
	float Temp;
	int i,j,Flag=0;

	if(REAR==-1) //Checks underflow
		cout<<"\n\nUnderflow! sorted ayyay is empty\n";
	 else
	 {
		cout<<"\n\nEnter the element to be deleted:";
		cin>>Temp;


		for(i=0;i<=REAR;i++)
			if(ARRAY[i]==Temp)             			// Finds the location of the element
			{
				Flag=1;
				break;
			}

		if(Flag==0)                       			// Element NOT found
			cout<<"\nElement NOT Found! Deletion Unsuccessful.\n";

		else
		{
			for(j=i;j<REAR;j++)
				ARRAY[j]=ARRAY[j+1];         			//Shifting of elements upward
			REAR--;
			cout<<"\nThe element "<<Temp<<" is deleted.\n";
		}
	 }
}


void SORTED_ARRAY::DISPLAY()
{
	if (REAR==-1) //Checks Empty Array
		cout<<"\n\nSorted Array is empty\n";
	 else
		{
			cout<<"\n\nELEMENTS PRESENT IN THE SORTED ARRAY :\n";
			for(int i=0;i<=REAR;i++)
				cout<<ARRAY[i]<<endl;
		}
}



void main()
{
	int choice;
	SORTED_ARRAY SA;
	do
	{
		cout<<"\n\nMAIN MENU:\n";
		cout<<"1.ADD AN ELEMENT INTO SORTED ARRAY\n";
		cout<<"2.DELETE AN ELEMENT FROM THE SORTED ARRAY\n";
		cout<<"3.DISPLAY THE SORTED ARRAY \n";
		cout<<"4.QUIT\n";
		choice=getche();
		cout<<endl;
		switch(choice)
		{
			case '1': SA.ADD(); break;
			case '2': SA.DELETE(); break;
			case '3': SA.DISPLAY(); break;
			case '4': break;
			default :cout<<"\nWrong Choice Entered !!\n\n";
		}
	}while(choice!='4');
}

